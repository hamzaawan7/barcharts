<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=tags_db',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8',
];
