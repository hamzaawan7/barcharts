/**
 Template Name: Abstack - Bootstrap 4 Web App kit
 Author: CoderThemes
 Email: coderthemes@gmail.com
 File: Chartjs
 */


!function ($) {
    "use strict";

    var ChartJs = function () {
    };

    ChartJs.prototype.respChart = function (selector, type, data, options) {
        // get selector by context
        //var ctx = selector.get(0).getContext("2d");
        var ctx = selector.get(0).getContext("2d");
        // pointing parent container to make chart js inherit its width
        var container = $(selector).parent();

        // enable resizing matter
        $(window).resize(generateChart);

        // this function produce the responsive Chart JS
        function generateChart() {
            // make chart width fit with its container
            var ww = selector.attr('width', $(container).width());
            switch (type) {
                case 'Bar':
                    new Chart(ctx, {type: 'bar', data: data, options: options});
                    break;
            }
            // Initiate new chart or Redraw

        };
        // run function - render chart at first load
        generateChart();
    },

        //init
        ChartJs.prototype.init = function () {
            //barchart
            this.respChart($("#bar1"), 'Bar', barChart1, barOpts);
            this.respChart($("#bar2"), 'Bar', barChart2, barOpts);
            this.respChart($("#bar3"), 'Bar', barChart3, barOpts);
        },
        $.ChartJs = new ChartJs, $.ChartJs.Constructor = ChartJs


}(window.jQuery),

//initializing
    function ($) {
        "use strict";
        $.ChartJs.init()
    }(window.jQuery);

